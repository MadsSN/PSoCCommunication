/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "stdbool.h"
#include "UART_MotorHandling.h"



CY_ISR(randomNavn)
{
    HandleData(UART_GetChar());
}


int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    UART_Start();   
    ISR_RX_UART_StartEx(randomNavn);
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */

    for(;;)
    {
        //steps of 5, every 1s. //What to make this smooth?
        for(int x = 1;x<7;x++){
            if(status[x]!=desiredStatus[x])
            {
                if(status[x]>desiredStatus[x]) status[x] = status[x] -5;
                else status[x] = status[x] + 5;
                //Set PWM with new status
                //SetPWM(int Axis,int Angle);
            }
        }
        CyDelay(1000);
        /* Place your application code here. */
    }
}

/* [] END OF FILE */
