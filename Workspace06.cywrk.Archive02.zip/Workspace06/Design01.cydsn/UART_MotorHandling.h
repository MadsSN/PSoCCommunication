/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "stdbool.h"

bool flag = false;
static char buffer[3];
static int counter = 0;
static char status[7];
static char desiredStatus[7];

void setDesiredStatus(){
    //Easy ones
    //Axis 2
    if(buffer[0]==192) desiredStatus[2] = status[2];
    else desiredStatus[2] = buffer[0]; 
    
    //Axis 3
    if(buffer[1]==192) desiredStatus[3] = status[3];
    else desiredStatus[3] = buffer[1]; 
    
    //Hard one
    //Axis 1
    if(buffer[2] & 0b10000000) desiredStatus[1] = 0;
    else if(buffer[2] & 0b01000000) desiredStatus[1] = 180;
    else desiredStatus[1] = status[1];
    
    //Axis 4
    if(buffer[2] & 0b00100000) desiredStatus[4] = 0;
    else if(buffer[2] & 0b00010000) desiredStatus[4] = 180;
    else desiredStatus[4] = status[4];
    
    //Axis 5
    if(buffer[2] & 0b00001000) desiredStatus[5] = 0;
    else if(buffer[2] & 0b00000100) desiredStatus[5] = 180;
    else desiredStatus[5] = status[5];
    
    //Axis 6
    if(buffer[2] & 0b00000010) desiredStatus[6] = 0;
    else if(buffer[2] & 0b00000001) desiredStatus[6] = 180;
    else desiredStatus[6] = status[6];
}

void HandleData(uint8 valueReceived){

    if(flag==false){
        if(valueReceived == 255){
            flag = true;
        }else if(valueReceived == 254){
            for(int x = 1;x<7;x++){
                UART_PutChar(status[x]);
            }
        }
    }else{
    buffer[counter] = valueReceived;
    counter++;
    if(counter == 3){
        counter = 0;
        flag = false;
        setDesiredStatus();
        }
    }
}


/* [] END OF FILE */
