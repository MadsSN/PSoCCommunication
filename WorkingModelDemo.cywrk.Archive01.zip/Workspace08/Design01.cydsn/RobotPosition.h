/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/* [] END OF FILE */

#ifndef RobotPosition_H__
#define RobotPosition_H__
#include "project.h"

    
    
typedef struct{
    uint8 data[7];
} RobotPosition;

#endif /* RobotPosition_H__*/