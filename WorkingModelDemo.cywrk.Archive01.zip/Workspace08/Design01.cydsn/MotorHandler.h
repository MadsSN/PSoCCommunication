/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/* [] END OF FILE */

#ifndef MotorHandler_H__
#define MotorHandler_H__
    
#include "RobotPosition.h"
#include "stdbool.h"
#include "stdlib.h"
#include "stdio.h"
RobotPosition currentPosition;
RobotPosition desiredPosition;


void doStepAxis(uint8 axis);
void setDesiredPosition(RobotPosition position);
uint8 bitcount(uint8* dataArray, uint8 size);
void reachStartPosition();
RobotPosition* getStatusPosition();
void doStep();
void initMotor();
void handleMotor();
void setMotorToTrue();


#endif /* MotorHandler_H__*/