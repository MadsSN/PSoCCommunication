/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "cyapicallbacks.h"
#include "RobotPosition.h"
#include "I2C.h"
#include "MotorHandler.h"


//Define variables. 

CY_ISR(TriggerMo){
    setMotorToTrue();
}


void I2C_1_ISR_ExitCallback(){
        if(0u != (I2C_1_SlaveStatus() & I2C_1_SSTAT_RD_CMPLT)){
            resetReadBuffer();
        }else if(0u != (I2C_1_SlaveStatus() & I2C_1_SSTAT_WR_CMPLT)){
            for(int x = 0;x<7;x++){
                UART_1_PutChar(wrbuf[x]);
            }
            
            setI2CtoTrue();
            resetWriteBuffer();
        }
}


int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    UART_1_Start();
    
    UART_1_PutString("I2C PSoC booted: \n");
    initI2C();
    initMotor();
    Timer_1_Start();
    Timer_Interrupt_StartEx(TriggerMo);
    
    PWM_1_Start();
    PWM_2_Start();
    PWM_3_Start();
    PWM_4_Start();
    PWM_5_Start();
    PWM_6_Start();
    
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */

    for(;;)
    {
        //doStep();
        handleI2C();
        handleMotor();
        
        /* Place your application code here. */
    }
}

/* [] END OF FILE */
