/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "I2C.h"
bool i2c = false;
void resetReadBuffer(){
    I2C_1_SlaveClearReadStatus();
    I2C_1_SlaveClearReadBuf();
}

void resetWriteBuffer(){
    I2C_1_SlaveClearWriteStatus();
    I2C_1_SlaveClearWriteBuf();
}

void initI2C(){
    RobotPosition* position = getStatusPosition();
    I2C_1_SlaveInitReadBuf(position->data, SIZE);
    I2C_1_SlaveInitWriteBuf(wrbuf, SIZE);
    resetReadBuffer();
    resetWriteBuffer();
    I2C_1_Start();
}

void writeCompleteI2C(){
        //Count ones
    uint8 countOfOnes = bitcount(wrbuf,SIZEFORLOOP);
    
    //Is data valid?
    //REMEMBER TO SET THIS AGAIN
    //if(countOfOnes == wrbuf[SIZEFORLOOP]){
    if(true){    
        //Enter data
        RobotPosition position;
        RobotPosition* currentPosition = getStatusPosition();
        for(int x = 0;x<SIZEFORLOOP;x++){
            if(wrbuf[x] == 192){
                position.data[x] = currentPosition->data[x];
            }else if(wrbuf[x]>=0 && wrbuf[x]<=180){
                position.data[x] = wrbuf[x];
            }else{
                position.data[x] = currentPosition->data[x];
            }
        }
        //Send data
        setDesiredPosition(position);
    }
    
    //Reset
    
}

void setI2CtoTrue(){
    i2c = true;
}

void handleI2C(){
    if(i2c == true){
        writeCompleteI2C();
        i2c = false;
    }   
}

/* [] END OF FILE */
