/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/* [] END OF FILE */

#include "MotorHandler.h"
#include "RobotPosition.h"
bool motor = false;

void print(){
    for(int x = 0;x<7;x++){
        UART_1_PutChar(currentPosition.data[x]);
    }
}

void initMotor(){
    for(int x = 0;x<6;x++){
        currentPosition.data[x] = 90;
    }
    setDesiredPosition(currentPosition);
    
    reachStartPosition();
}

void reachStartPosition(){
    doStep();
}


RobotPosition* getStatusPosition(){
    return &currentPosition;
}

void setDesiredPosition(RobotPosition position){
    desiredPosition = position;
}

void doStep(){
    
    for(uint8 x = 0;x<6;x++){
        doStepAxis(x);
    }
}

//Credits for below bitcount function given to: https://bisqwit.iki.fi/source/misc/bitcounting/ as of 29-10-2018, for inspiration. 
uint8 bitcount(uint8* dataArray, uint8 size)
{
    unsigned count = 0;
    uint8 temp = dataArray[0];
    for(uint8 x = 0;x<size;x++){
        temp = dataArray[x];
    	while (temp) {
		count += (temp & 1);
		temp >>= 1;
	    }
    }
    return count;
}

void doStepAxis(uint8 axis){
    //Do step
    
    if(currentPosition.data[axis]>desiredPosition.data[axis]){
        currentPosition.data[axis]--;
    }else if(currentPosition.data[axis]<desiredPosition.data[axis]){
        currentPosition.data[axis]++;
    }
    //Set correct validation byte
    currentPosition.data[6] = bitcount(currentPosition.data,6); 
   // char buffer[7] = &currentPosition.data;
    
    //Do it on the motor
    
    switch (axis+1) {
    case 1:
    {
        int axisAngle = currentPosition.data[axis];
        int linearFactor1 = -1.3369*axisAngle + 333.02;
        PWM_1_WriteCompare(linearFactor1);
        break;
    }
    case 2:
    {
        
        int axisAngle = 45 + currentPosition.data[axis]*0.5;
        int linearFactor2 = 1.337*axisAngle + 92.977;
        PWM_2_WriteCompare(linearFactor2);
        break;
    }
    case 3:
        //setAngleMotor3(currentPosition.data[axis]);
    break;
    case 4:
        
        //setAngleMotor4(currentPosition.data[axis]);
    break;
    case 5: 
    {
        int axisAngle = currentPosition.data[axis];
        int linearFactor5 = 1.4086*axisAngle + 97.678;
        PWM_5_WriteCompare(linearFactor5);
        break;  
    }
    case 6:
        //setAngleMotor6(currentPosition.data[axis]);
    break;
    
    default:
    break;
    }
}

void handleMotor(){
    if(motor == true){
    doStep();
    motor = false;
    }
}

void setMotorToTrue(){
    motor = true;
}