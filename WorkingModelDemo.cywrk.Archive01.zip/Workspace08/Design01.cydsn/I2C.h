/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/* [] END OF FILE */

#ifndef I2C_H__
#define I2C_H__
    
#include "project.h"
#include "MotorHandler.h"
#include "stdbool.h"
#define SIZE 7
#define SIZEFORLOOP 6
uint8 wrbuf[SIZE];



void resetReadBuffer();
void resetWriteBuffer();
void initI2C();
void writeCompleteI2C();
void handleI2C();
void setI2CtoTrue();

#endif /* I2C_H__*/